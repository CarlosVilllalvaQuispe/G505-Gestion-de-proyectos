import Landing from './Landing';

export default function Home() {
  return (
    <>
      <Landing />
    </>
  );
}
